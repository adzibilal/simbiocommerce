(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_cbc40e4b._.css",
  "static/chunks/src_ad8f9272._.js",
  "static/chunks/node_modules_5c8323c2._.js"
],
    source: "dynamic"
});
