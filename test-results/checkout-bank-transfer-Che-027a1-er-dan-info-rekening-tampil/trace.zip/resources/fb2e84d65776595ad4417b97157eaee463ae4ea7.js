(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_cf17987a._.js",
  "static/chunks/node_modules_9aa0daa6._.js",
  "static/chunks/node_modules_swiper_modules_pagination_0f93743a.css"
],
    source: "dynamic"
});
